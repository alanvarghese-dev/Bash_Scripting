# File Backup Script Project

This project implements a robust Bash script for automating backups, a core task in DevOps for ensuring data durability and disaster recovery.

## DevOps Principles Applied

*   **Automation**: Replacing manual, error-prone backup tasks with a repeatable script.
*   **Infrastructure as Code (IaC) (lite)**: Managing backup configurations through code/config files.
*   **Logging and Monitoring**: Providing visibility into the success or failure of backup jobs.
*   **Security**: Using `ssh` and `scp` for secure data transfer.
*   **Resource Management**: Implementing retention policies to prevent disk space exhaustion.

## Features

1.  **Compression**: Archives and compresses source directories using `tar` and `gzip`.
2.  **Remote Transfer**: Securely transfers backups to a remote server via `scp`.
3.  **Retention Policy**: Deletes local and (optionally) remote backups older than `N` days.
4.  **Logging**: Detailed logs for auditing and troubleshooting.
5.  **Configuration**: Externalized settings for ease of management across different environments.
6.  **Error Handling**: Robust checks to ensure data integrity and catch failures early.

## Project Structure

- `backup.sh`: The main execution script.
- `backup.conf`: Configuration file (source paths, remote details, retention).
- `logs/`: Directory for backup execution logs.
- `backups/`: Local staging area for backup archives.

## Lessons Learned & Key Concepts

### Bash Commands Explained

-   **`tar -czf`**:
    -   `-c`: Create a new archive.
    -   `-z`: Filter the archive through gzip (compression).
    -   `-f`: Use archive file (must be followed by the filename).
-   **`find ... -mtime +N -exec rm {} \;`**:
    -   `find`: Search for files.
    -   `-mtime +N`: Find files modified more than N days ago.
    -   `-exec ... \;`: Execute a command on each found file. `{}` is a placeholder for the filename.
-   **`getopts`**: A built-in Bash utility for parsing command-line options. It makes scripts professional and flexible.
-   **`source`**: Executes a file in the current shell context, allowing you to load variables from a configuration file.

### DevOps Best Practices

1.  **Separation of Concerns**: Keeping configuration (`backup.conf`) separate from logic (`backup.sh`) allows the same script to be used in multiple environments (Dev, QA, Prod) without modification.
2.  **Dry Run Mode**: Implementing a `-d` flag is a safety-first approach. It allows operators to verify what a script *will* do before it actually modifies the system.
3.  **Idempotency & Resilience**: The script checks for directory existence (`mkdir -p`) and valid source paths before proceeding, making it more resilient to environment changes.
4.  **Logging**: In DevOps, if it wasn't logged, it didn't happen. Comprehensive logs are essential for debugging automated tasks that run while you're asleep.
5.  **Retention**: Managing the lifecycle of data is crucial for infrastructure stability. Automatically deleting old backups prevents "disk full" alerts.

## Future Enhancements

-   Add support for AWS S3 using `aws s3 cp`.
-   Implement Slack/Email notifications on failure.
-   Add checksum verification after transfer.
